#!/bin/bash

name=arpitkhameshra

echo "My name is $name"

echo "What is your channel name?"

read channel

echo "do subsribe $channel"
