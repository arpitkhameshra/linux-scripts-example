#!/bin/bash

name=arpit
val=1
if [ $val -eq 2 ]
then	
	echo "yes arpit logged in"
else
	echo "input is wrong"
fi
