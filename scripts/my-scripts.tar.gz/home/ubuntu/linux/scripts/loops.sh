#!/bin/bash

dir=/home/ubuntu/linux/scripts/*.*

for files in $dir
do
	echo $files

done
