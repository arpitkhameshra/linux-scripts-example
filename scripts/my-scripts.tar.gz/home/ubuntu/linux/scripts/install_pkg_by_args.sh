#!/bin/bash

sudo apt install $1
